---
layout: ../../layouts/MarkdownPostLayout.astro
title: 'Mi primera publicación en el blog'
pubDate: 2026-08-12
description: 'Este es la primera publicación de mi nuevo blog Astro.'
author: 'Alumno de Astro'
image:
    url: 'https://docs.astro.build/assets/rose.webp'
    alt: 'El logotipo de Astro sobre un fondo oscuro con un brillo rosado.'
tags: ["astro", "bloguear", "aprender en público"]

---

# Mi primera publicación en el blog


¡Bienvenido a mi _nuevo blog_ sobre el aprendizaje de Astro! Aquí, voy a compartir mi viaje de aprendizaje a medida que construyo un nuevo sitio web.

## Lo que he conseguido

1. **Instalación de Astro**: En primer lugar, he creado un nuevo proyecto Astro y configurar mis cuentas en línea.

2. **Creación de páginas**: Luego aprendí cómo hacer páginas creando nuevos archivos `.astro` y colocándolos en la carpeta `src/pages/`.

3. **Creación de publicaciones**: ¡Esta es mi primera publicación! ¡Ahora tengo páginas de Astro y publicaciónes en Markdown!

## Próximos pasos

Terminaré el tutorial de Astro, y luego seguiré añadiendo más publicaciones. Mira este espacio para más por venir.