---
layout: ../../layouts/MarkdownPostLayout.astro
title: Mi segunda publicación en el blog
author: Alumno de Astro
description: "Después de aprender un poco de Astro, ¡no podía parar!"
image:
    url: "https://docs.astro.build/assets/arc.webp"
    alt: "El logotipo de Astro sobre un fondo oscuro con un arco degradado en tonos púrpura."
pubDate: 2026-08-12
tags: ["astro", "bloguear", "aprender en público", "éxitos"]
---
Después de una exitosa primera semana aprendiendo Astro, decidí probar un poco más. Escribí e importé un pequeño componente de memoria.